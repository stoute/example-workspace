import React from 'react';
import { render } from '@testing-library/react';
// import { BsmSlider} from '@bsmp/webcomponents-react';

import App from './App';

jest.mock('react-i18next', () => ({
  useTranslation: () => ({t: key => key})
}));

describe('App', () => {
  it('should render Aoo component successfully', () => {
    const { baseElement } = render(<App />);
    expect(baseElement).toBeTruthy();
  });
  // it('should render @bsmp/webcomponents-react component successfully', () => {
  //   const { baseElement } = render(<BsmSlider />);
  //   expect(baseElement).toBeTruthy();
  // });
});
